# Nico Party

YouTube、Amazon Prime Video、ニコニコ動画で、同じルームに参加したブラウザ間の再生・停止・シーク・再生速度を同期するChrome/Edge拡張機能です。

## インストール

1. Chromeでは `chrome://extensions`、Edgeでは `edge://extensions` を開く
2. 「デベロッパーモード」を有効にする
3. 「パッケージ化されていない拡張機能を読み込む」で、このフォルダーを選ぶ

## 使い方

1. 全員が同じ動画ページを開く
2. 一人が拡張機能を開き、「今の再生位置でルーム作成」を押す
3. 表示されたルームIDを共有する
4. 他の人がルームIDを入力して「参加」を押す

ルームは最後のアクセスから12時間で自動的に消えます。Amazon Prime Videoは地域やプレイヤー更新によって動画要素を検出できない場合があります。

## build

cd /d C:\Users\nanoa\projects\nico-party

tar -a -c -f nico-party-extension.zip manifest.json background.js content.js popup.html popup.css popup.js README.md